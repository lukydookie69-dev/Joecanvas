// ── Date header ────────────────────────────────────────────────────────────
document.getElementById("header-date").textContent = new Date().toLocaleDateString("en", {
  weekday: "long", month: "long", day: "numeric"
});

// ── Helpers ────────────────────────────────────────────────────────────────
function formatDueDate(dateStr) {
  if (!dateStr) return { label: "No due date", cls: "" };
  const due  = new Date(dateStr);
  const now  = new Date();
  const diff = (due - now) / 36e5;

  if (diff < 0)   return { label: "Overdue",    cls: "overdue"  };
  if (diff < 24)  return { label: `Due in ${Math.round(diff)}h`, cls: "due-soon" };
  if (diff < 48)  return { label: "Due tomorrow", cls: "due-soon" };
  if (diff < 168) return {
    label: `Due ${due.toLocaleDateString("en", { weekday: "short", month: "short", day: "numeric" })}`,
    cls: ""
  };
  return {
    label: due.toLocaleDateString("en", { month: "long", day: "numeric" }),
    cls: ""
  };
}

function cardClass(dateStr) {
  if (!dateStr) return "normal";
  const diff = (new Date(dateStr) - new Date()) / 36e5;
  if (diff < 0)  return "overdue";
  if (diff < 48) return "due-soon";
  return "normal";
}

// ── Canvas API ─────────────────────────────────────────────────────────────
async function fetchUpcoming(baseUrl, token, bust = false) {
  if (!bust) {
    const local = await chrome.storage.local.get("upcoming_cache");
    if (local.upcoming_cache) {
      const { data, ts } = local.upcoming_cache;
      if (Date.now() - ts < 5 * 60 * 1000) return data;
    }
  }
  const res = await fetch(`${baseUrl}/api/v1/users/self/upcoming_events?per_page=20`, {
    headers: { Authorization: `Bearer ${token}` }
  });
  if (!res.ok) throw new Error(`Canvas returned ${res.status}`);
  const data = await res.json();
  chrome.storage.local.set({ upcoming_cache: { data, ts: Date.now() } });
  return data;
}

// ── Render assignments ──────────────────────────────────────────────────────
async function renderAssignments(events) {
  const grid = document.getElementById("assignments-grid");

  if (!events.length) {
    grid.innerHTML = '<div class="empty">Nothing due soon — enjoy the break.</div>';
    return;
  }

  const allStorage = await chrome.storage.sync.get(null);

  grid.innerHTML = "";
  events.forEach(ev => {
    const dueAt  = ev.assignment?.due_at ?? ev.start_at ?? null;
    const points = ev.assignment?.points_possible;
    const { label: dueLabel, cls: dueCls } = formatDueDate(dueAt);
    const cls = cardClass(dueAt);

    // Pull saved note for this assignment if it exists
    const aMatch = ev.html_url?.match(/assignments\/(\d+)/);
    const savedNote = aMatch ? (allStorage[`assignment_${aMatch[1]}`]?.notes ?? "") : "";

    const card = document.createElement("div");
    card.className = `assignment-card ${cls}`;
    card.innerHTML = `
      <div class="card-top">
        <div style="min-width:0">
          <div class="card-course">${ev.context_name ?? ""}</div>
          <div class="card-title">${ev.title}</div>
        </div>
        <div class="card-due">
          <div class="due-label">Due</div>
          <div class="due-value ${dueCls}">${dueLabel}</div>
        </div>
      </div>
      <div class="card-meta">
        ${points != null ? `<span>${points} pts</span>` : ""}
        ${ev.assignment?.submission_types?.length
          ? `<span>${ev.assignment.submission_types.join(", ").replace(/_/g, " ")}</span>`
          : ""}
      </div>
      ${savedNote ? `<div class="card-note">${savedNote}</div>` : ""}
      <div class="card-actions">
        <a class="btn-primary" href="${ev.html_url}" target="_blank">Open Assignment</a>
        <button class="btn-secondary open-ws-for-assignment">Open Workspace</button>
      </div>`;

    // Try to find a matching workspace by assignment or course ID from the URL
    card.querySelector(".open-ws-for-assignment").addEventListener("click", async () => {
      const all = await chrome.storage.sync.get(null);
      // Try to match by html_url assignment ID
      const aMatch = ev.html_url?.match(/assignments\/(\d+)/);
      const cMatch = ev.html_url?.match(/courses\/(\d+)/);
      const aKey = aMatch ? `assignment_${aMatch[1]}` : null;
      const cKey = cMatch ? `course_${cMatch[1]}`     : null;
      const aWS  = aKey ? all[aKey] : null;
      const cWS  = cKey ? all[cKey] : null;
      const urls = [...(cWS?.urls ?? []), ...(aWS?.urls ?? [])];
      if (urls.length) {
        urls.forEach(({ url }) => window.open(url, "_blank"));
      } else {
        card.querySelector(".open-ws-for-assignment").textContent = "No workspace saved";
        card.querySelector(".open-ws-for-assignment").disabled = true;
      }
    });

    grid.appendChild(card);
  });
}

// ── Render workspaces ──────────────────────────────────────────────────────
async function renderWorkspaces() {
  const list = document.getElementById("workspaces-list");
  const all  = await chrome.storage.sync.get(null);
  const entries = Object.entries(all).filter(([k]) =>
    k.startsWith("course_") || k.startsWith("assignment_")
  );

  if (!entries.length) {
    list.innerHTML = '<div class="empty">No workspaces yet.<br>Press Alt+D on a Canvas assignment to create one.</div>';
    return;
  }

  list.innerHTML = "";
  entries.forEach(([key, ws]) => {
    const name  = ws.name || key.replace(/_/g, " ");
    const type  = key.startsWith("course_") ? "Course" : "Assignment";
    const urls  = ws.urls ?? [];

    const card = document.createElement("div");
    card.className = "workspace-card";
    card.innerHTML = `
      <div class="ws-header">
        <span class="ws-name">${name}</span>
        <span class="ws-badge">${type}</span>
      </div>
      <div class="ws-links">
        ${urls.length
          ? urls.map(({ label, url }) => `
            <div class="ws-link-row">
              <span class="ws-link-label">${label}</span>
              <a class="ws-link-url" href="${url}" target="_blank" title="${url}">${url}</a>
            </div>`).join("")
          : '<div style="font-size:12px;color:#333;padding:4px 0">No links saved</div>'
        }
      </div>
      <button class="ws-open-btn">Open All ${urls.length ? `(${urls.length})` : ""}</button>`;

    card.querySelector(".ws-open-btn").addEventListener("click", () => {
      urls.forEach(({ url }) => window.open(url, "_blank"));
    });

    list.appendChild(card);
  });
}

// ── Init ───────────────────────────────────────────────────────────────────
async function init(bust = false) {
  const grid = document.getElementById("assignments-grid");
  const { canvas_url, canvas_token } = await chrome.storage.sync.get(["canvas_url", "canvas_token"]);

  if (!canvas_url || !canvas_token) {
    grid.innerHTML = `
      <div class="setup-card">
        <p>Connect Canvas to see your upcoming assignments.<br><br>
        Open the <strong>StudyLauncher popup</strong> → click ⚙ Settings → enter your Canvas URL and API token.</p>
      </div>`;
  } else {
    try {
      const events = await fetchUpcoming(canvas_url, canvas_token, bust);
      renderAssignments(events);
    } catch (err) {
      grid.innerHTML = `<div class="error-msg">Couldn't load assignments: ${err.message}<br>Check your token in Settings.</div>`;
    }
  }

  await renderWorkspaces();
}

document.getElementById("refresh-btn").addEventListener("click", () => {
  document.getElementById("assignments-grid").innerHTML = '<div class="loading">Loading…</div>';
  document.getElementById("workspaces-list").innerHTML  = '<div class="loading">Loading…</div>';
  init(true);
});

init();
