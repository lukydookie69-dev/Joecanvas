chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "OPEN_TABS") {
    msg.urls.forEach(({ url }) => chrome.tabs.create({ url }));
  }
  if (msg.type === "OPEN_POPUP") {
    chrome.action.openPopup();
  }
});

chrome.commands.onCommand.addListener((command) => {
  if (command === "toggle-bar") {
    chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
      if (tab?.id) chrome.tabs.sendMessage(tab.id, { type: "TOGGLE_BAR" });
    });
  }
});
