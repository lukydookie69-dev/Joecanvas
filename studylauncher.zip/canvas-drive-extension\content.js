let barOpen = false;
let shadowHost = null;
let results = [];
let selectedIndex = 0;

// ── Canvas context ──────────────────────────────────────────────────────────
function getCanvasInfo() {
  const match = window.location.pathname.match(/\/courses\/(\d+)\/assignments\/(\d+)/);
  if (!match) return null;
  return { courseId: match[1], assignmentId: match[2] };
}

// ── Highlight matching text ─────────────────────────────────────────────────
function highlight(text, query) {
  if (!query) return text;
  const idx = text.toLowerCase().indexOf(query.toLowerCase());
  if (idx === -1) return text;
  return text.slice(0, idx)
    + `<mark>${text.slice(idx, idx + query.length)}</mark>`
    + text.slice(idx + query.length);
}

// ── Build result list from storage ─────────────────────────────────────────
async function loadResults(query = "") {
  const all = await chrome.storage.sync.get(null);
  const canvasInfo = getCanvasInfo();

  const workspaces = Object.entries(all)
    .filter(([k]) => k.startsWith("course_") || k.startsWith("assignment_"))
    .map(([key, ws]) => ({
      type: key.startsWith("course_") ? "Course" : "Assignment",
      name: ws.name || key.replace(/_/g, " "),
      urls: ws.urls || [],
      key,
      active: canvasInfo && (
        key === `course_${canvasInfo.courseId}` ||
        key === `assignment_${canvasInfo.assignmentId}`
      )
    }))
    .filter(w => !query || w.name.toLowerCase().includes(query.toLowerCase()))
    .sort((a, b) => {
      if (a.active && !b.active) return -1;
      if (!a.active && b.active) return 1;
      if (a.type === "Course" && b.type !== "Course") return -1;
      if (a.type !== "Course" && b.type === "Course") return 1;
      return a.name.localeCompare(b.name);
    });

  // Upcoming assignments from cache
  const { upcoming_cache } = await chrome.storage.local.get("upcoming_cache");
  const upcoming = (upcoming_cache?.data ?? [])
    .filter(ev => !query || ev.title.toLowerCase().includes(query.toLowerCase()))
    .slice(0, 4)
    .map(ev => ({
      type: "Upcoming",
      name: ev.title,
      subtitle: ev.context_name ?? "",
      url: ev.html_url,
      dueAt: ev.assignment?.due_at ?? ev.start_at ?? null,
    }));

  return [...workspaces, ...upcoming];
}

function formatDue(dateStr) {
  if (!dateStr) return "";
  const diff = (new Date(dateStr) - new Date()) / 36e5;
  if (diff < 0)   return "Overdue";
  if (diff < 24)  return `${Math.round(diff)}h left`;
  if (diff < 48)  return "Due tomorrow";
  return `Due ${new Date(dateStr).toLocaleDateString("en", { weekday: "short", month: "short", day: "numeric" })}`;
}

function dueColor(dateStr) {
  if (!dateStr) return "#555";
  const diff = (new Date(dateStr) - new Date()) / 36e5;
  if (diff < 0)  return "#e05252";
  if (diff < 48) return "#f5a623";
  return "#555";
}

// ── Render results into shadow DOM ──────────────────────────────────────────
function renderResults(shadow, query) {
  const list = shadow.getElementById("sl-list");
  const empty = shadow.getElementById("sl-empty");

  list.innerHTML = "";
  if (!results.length) {
    empty.style.display = "block";
    return;
  }
  empty.style.display = "none";

  results.forEach((r, i) => {
    const item = document.createElement("div");
    item.className = "sl-item" + (i === selectedIndex ? " sl-selected" : "");
    item.dataset.index = i;

    if (r.type === "Upcoming") {
      const due = formatDue(r.dueAt);
      item.innerHTML = `
        <div class="sl-item-icon sl-icon-upcoming">↗</div>
        <div class="sl-item-body">
          <div class="sl-item-name">${highlight(r.name, query)}</div>
          <div class="sl-item-sub">${r.subtitle}${due ? ` · <span style="color:${dueColor(r.dueAt)}">${due}</span>` : ""}</div>
        </div>
        <div class="sl-item-action">Open</div>`;
    } else {
      const linkTxt = r.urls.length ? `${r.urls.length} link${r.urls.length !== 1 ? "s" : ""}` : "No links";
      item.innerHTML = `
        <div class="sl-item-icon ${r.active ? "sl-icon-active" : "sl-icon-ws"}">${r.type === "Course" ? "⊞" : "◈"}</div>
        <div class="sl-item-body">
          <div class="sl-item-name">${highlight(r.name, query)}${r.active ? ' <span class="sl-badge">current</span>' : ""}</div>
          <div class="sl-item-sub">${r.type} · ${linkTxt}</div>
        </div>
        <div class="sl-item-action">Open All</div>`;
    }

    item.addEventListener("mouseenter", () => {
      selectedIndex = i;
      renderResults(shadow, query);
    });
    item.addEventListener("click", () => activateResult(r));
    list.appendChild(item);
  });
}

function activateResult(r) {
  if (r.type === "Upcoming") {
    chrome.runtime.sendMessage({ type: "OPEN_TABS", urls: [{ url: r.url }] });
  } else {
    if (r.urls.length) chrome.runtime.sendMessage({ type: "OPEN_TABS", urls: r.urls });
  }
  closeBar();
}

// ── Open / close ────────────────────────────────────────────────────────────
function openBar() {
  if (barOpen) { closeBar(); return; }
  barOpen = true;
  selectedIndex = 0;

  shadowHost = document.createElement("div");
  shadowHost.id = "studylauncher-host";
  document.body.appendChild(shadowHost);

  const shadow = shadowHost.attachShadow({ mode: "open" });
  shadow.innerHTML = `
    <style>
      * { box-sizing: border-box; margin: 0; padding: 0; }
      :host { all: initial; }

      .sl-overlay {
        position: fixed; inset: 0; z-index: 2147483647;
        background: rgba(0,0,0,0.6);
        backdrop-filter: blur(6px);
        display: flex; align-items: flex-start; justify-content: center;
        padding-top: 14vh;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Inter", sans-serif;
        -webkit-font-smoothing: antialiased;
      }

      .sl-bar {
        width: 560px;
        background: #141414;
        border: 1px solid #272727;
        border-radius: 14px;
        box-shadow: 0 32px 80px rgba(0,0,0,0.7), 0 0 0 1px rgba(255,255,255,0.04);
        overflow: hidden;
        animation: sl-in 0.15s cubic-bezier(0.16,1,0.3,1);
      }

      @keyframes sl-in {
        from { opacity: 0; transform: scale(0.96) translateY(-8px); }
        to   { opacity: 1; transform: scale(1)    translateY(0); }
      }

      .sl-search {
        display: flex; align-items: center; gap: 10px;
        padding: 14px 16px;
        border-bottom: 1px solid #1e1e1e;
      }
      .sl-search-icon { font-size: 16px; color: #444; flex-shrink: 0; }
      .sl-input {
        flex: 1; background: none; border: none; outline: none;
        font-size: 15px; font-weight: 500; color: #f0f0f0;
        font-family: inherit;
        caret-color: #4f8ef7;
      }
      .sl-input::placeholder { color: #333; }
      .sl-esc {
        font-size: 10px; color: #333; background: #1e1e1e;
        border: 1px solid #2a2a2a; border-radius: 5px;
        padding: 2px 7px; flex-shrink: 0; font-family: inherit;
      }

      .sl-list { max-height: 340px; overflow-y: auto; padding: 6px; }
      .sl-list::-webkit-scrollbar { width: 4px; }
      .sl-list::-webkit-scrollbar-track { background: transparent; }
      .sl-list::-webkit-scrollbar-thumb { background: #2a2a2a; border-radius: 2px; }

      .sl-item {
        display: flex; align-items: center; gap: 10px;
        padding: 10px 12px; border-radius: 8px; cursor: pointer;
        transition: background 0.1s;
      }
      .sl-item.sl-selected { background: #1e1e1e; }
      .sl-item.sl-selected .sl-item-action { opacity: 1; }

      .sl-item-icon {
        width: 30px; height: 30px; border-radius: 7px;
        display: flex; align-items: center; justify-content: center;
        font-size: 13px; flex-shrink: 0;
      }
      .sl-icon-ws       { background: #1a1a1a; color: #555; border: 1px solid #222; }
      .sl-icon-active   { background: rgba(79,142,247,0.12); color: #4f8ef7; border: 1px solid rgba(79,142,247,0.2); }
      .sl-icon-upcoming { background: rgba(245,166,35,0.1); color: #f5a623; border: 1px solid rgba(245,166,35,0.2); }

      .sl-item-body { flex: 1; min-width: 0; }
      .sl-item-name {
        font-size: 13px; font-weight: 500; color: #e8e8e8;
        white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
      }
      .sl-item-name mark { background: none; color: #4f8ef7; font-weight: 700; }
      .sl-badge {
        display: inline-block; font-size: 9px; font-weight: 700;
        text-transform: uppercase; letter-spacing: 0.07em;
        color: #4f8ef7; background: rgba(79,142,247,0.12);
        border-radius: 4px; padding: 1px 5px; margin-left: 5px;
        vertical-align: middle;
      }
      .sl-item-sub { font-size: 11px; color: #444; margin-top: 2px; }

      .sl-item-action {
        font-size: 11px; font-weight: 600; color: #4f8ef7;
        opacity: 0; transition: opacity 0.1s; flex-shrink: 0;
        white-space: nowrap;
      }

      .sl-empty {
        display: none; text-align: center; padding: 28px 16px;
        font-size: 13px; color: #333;
      }

      .sl-footer {
        display: flex; gap: 16px; align-items: center;
        padding: 9px 16px; border-top: 1px solid #1a1a1a;
        background: #101010;
      }
      .sl-hint { display: flex; gap: 5px; align-items: center; font-size: 11px; color: #333; }
      .sl-key {
        background: #1e1e1e; border: 1px solid #2a2a2a; border-radius: 4px;
        padding: 1px 6px; font-size: 10px; color: #555; font-family: inherit;
      }
    </style>

    <div class="sl-overlay" id="sl-overlay">
      <div class="sl-bar">
        <div class="sl-search">
          <span class="sl-search-icon">⌕</span>
          <input class="sl-input" id="sl-input" placeholder="Search workspaces and assignments…" autocomplete="off" spellcheck="false" />
          <span class="sl-esc">esc</span>
        </div>
        <div class="sl-list" id="sl-list"></div>
        <div class="sl-empty" id="sl-empty">No results</div>
        <div class="sl-footer">
          <div class="sl-hint"><span class="sl-key">↑↓</span> navigate</div>
          <div class="sl-hint"><span class="sl-key">↵</span> open</div>
          <div class="sl-hint"><span class="sl-key">esc</span> close</div>
        </div>
      </div>
    </div>`;

  // Click backdrop to close
  shadow.getElementById("sl-overlay").addEventListener("click", (e) => {
    if (e.target.id === "sl-overlay") closeBar();
  });

  const input = shadow.getElementById("sl-input");
  input.focus();

  // Load and render initial results
  loadResults("").then(r => {
    results = r;
    renderResults(shadow, "");
  });

  // Search on type
  input.addEventListener("input", async () => {
    const q = input.value.trim();
    results = await loadResults(q);
    selectedIndex = 0;
    renderResults(shadow, q);
  });

  // Keyboard navigation
  input.addEventListener("keydown", (e) => {
    if (e.key === "Escape") { closeBar(); return; }

    if (e.key === "ArrowDown") {
      e.preventDefault();
      selectedIndex = Math.min(selectedIndex + 1, results.length - 1);
      renderResults(shadow, input.value.trim());
      scrollSelected(shadow);
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      selectedIndex = Math.max(selectedIndex - 1, 0);
      renderResults(shadow, input.value.trim());
      scrollSelected(shadow);
    } else if (e.key === "Enter") {
      if (results[selectedIndex]) activateResult(results[selectedIndex]);
    }
  });
}

function scrollSelected(shadow) {
  const list = shadow.getElementById("sl-list");
  const sel  = list.querySelector(".sl-selected");
  if (sel) sel.scrollIntoView({ block: "nearest" });
}

function closeBar() {
  if (shadowHost) { shadowHost.remove(); shadowHost = null; }
  barOpen = false;
}

// ── Hotkey ──────────────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "TOGGLE_BAR") openBar();
});

document.addEventListener("keydown", (e) => {
  if (e.key === "Escape" && barOpen) closeBar();
});
