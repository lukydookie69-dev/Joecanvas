// ── State ──────────────────────────────────────────────────────────────────
let courseKey     = null;
let assignmentKey = null;
let courseWS      = { urls: [] };
let assignmentWS  = { urls: [] };

// ── View switching ─────────────────────────────────────────────────────────
function showView(id) {
  document.querySelectorAll(".view").forEach(v => v.classList.remove("active"));
  document.getElementById(id).classList.add("active");
}

// ── Settings ───────────────────────────────────────────────────────────────
document.getElementById("dashboard-btn").addEventListener("click", () => {
  chrome.tabs.create({ url: chrome.runtime.getURL("dashboard.html") });
  window.close();
});

document.getElementById("settings-btn").addEventListener("click", () => {
  const isOpen = document.getElementById("settings-view").classList.contains("active");
  if (isOpen) {
    init();
  } else {
    // Load saved values (including mid-edit drafts)
    chrome.storage.sync.get(["canvas_url", "canvas_token"], (s) => {
      document.getElementById("canvas-url-input").value   = s.canvas_url   || "";
      document.getElementById("canvas-token-input").value = s.canvas_token || "";
    });
    showView("settings-view");
  }
});

// Auto-save as the user types so closing the popup doesn't erase their input
document.getElementById("canvas-url-input").addEventListener("input", (e) => {
  chrome.storage.sync.set({ canvas_url: e.target.value.trim().replace(/\/$/, "") });
});
document.getElementById("canvas-token-input").addEventListener("input", (e) => {
  chrome.storage.sync.set({ canvas_token: e.target.value.trim() });
});

document.getElementById("save-settings-btn").addEventListener("click", () => {
  const url   = document.getElementById("canvas-url-input").value.trim().replace(/\/$/, "");
  const token = document.getElementById("canvas-token-input").value.trim();
  const status = document.getElementById("settings-status");

  if (!url.startsWith("http") || !token) {
    status.style.color = "#e55";
    status.textContent = "Please fill in both fields.";
    return;
  }

  chrome.storage.sync.set({ canvas_url: url, canvas_token: token }, () => {
    chrome.storage.local.remove("upcoming_cache");  // bust cache on credential change
    status.style.color = "#4a4";
    status.textContent = "Saved!";
    setTimeout(() => init(), 800);
  });
});

// ── Canvas API ─────────────────────────────────────────────────────────────
async function fetchUpcoming(baseUrl, token) {
  const local = await chrome.storage.local.get("upcoming_cache");
  if (local.upcoming_cache) {
    const { data, ts } = local.upcoming_cache;
    if (Date.now() - ts < 5 * 60 * 1000) return data;
  }
  const res = await fetch(`${baseUrl}/api/v1/users/self/upcoming_events?per_page=10`, {
    headers: { Authorization: `Bearer ${token}` }
  });
  if (!res.ok) throw new Error(`Canvas API error ${res.status}`);
  const data = await res.json();
  chrome.storage.local.set({ upcoming_cache: { data, ts: Date.now() } });
  return data;
}

function formatDue(dateStr) {
  if (!dateStr) return "No due date";
  const due  = new Date(dateStr);
  const now  = new Date();
  const diff = (due - now) / 36e5; // hours
  if (diff < 0)   return "Overdue";
  if (diff < 24)  return `Due in ${Math.round(diff)}h`;
  if (diff < 168) return `Due ${due.toLocaleDateString("en", { weekday: "short", month: "short", day: "numeric" })}`;
  return due.toLocaleDateString("en", { month: "short", day: "numeric" });
}

function dotClass(dateStr) {
  if (!dateStr) return "";
  const diff = (new Date(dateStr) - new Date()) / 36e5;
  if (diff < 0)  return "overdue";
  if (diff < 48) return "due-soon";
  return "";
}

async function renderUpcoming() {
  const el = document.getElementById("upcoming-list");
  const { canvas_url, canvas_token } = await chrome.storage.sync.get(["canvas_url", "canvas_token"]);

  if (!canvas_url || !canvas_token) {
    el.innerHTML = `<div class="upcoming-setup">
      Add your Canvas credentials in <a id="setup-link">Settings ⚙</a> to see upcoming assignments.
    </div>`;
    el.querySelector("#setup-link").addEventListener("click", () => showView("settings-view"));
    return;
  }

  try {
    const events = await fetchUpcoming(canvas_url, canvas_token);
    if (!events.length) {
      el.innerHTML = '<div class="upcoming-empty">Nothing due soon.</div>';
      return;
    }
    el.innerHTML = "";
    events.slice(0, 6).forEach(ev => {
      const dueAt = ev.assignment?.due_at ?? ev.start_at;
      const a = document.createElement("a");
      a.className = "upcoming-item";
      a.href = ev.html_url || "#";
      a.target = "_blank";
      a.innerHTML = `
        <div class="due-pip ${dotClass(dueAt)}"></div>
        <div style="min-width:0;flex:1">
          <div class="upcoming-name">${ev.title}</div>
          <div class="upcoming-meta">${ev.context_name ?? ""} · ${formatDue(dueAt)}</div>
        </div>`;
      el.appendChild(a);
    });
  } catch (err) {
    el.innerHTML = `<div class="upcoming-error">Couldn't load assignments — check your token in Settings.</div>`;
  }
}

// ── URL list rendering ─────────────────────────────────────────────────────
function renderList(listEl, workspace, storageKey) {
  listEl.innerHTML = "";
  if (!workspace.urls.length) {
    listEl.innerHTML = '<div class="empty-state">No links yet.</div>';
    return;
  }
  workspace.urls.forEach(({ label, url }, i) => {
    const item = document.createElement("div");
    item.className = "url-item";
    item.innerHTML = `
      <span class="url-label">${label || "Link"}</span>
      <a class="url-link" href="${url}" target="_blank" title="${url}">${url}</a>
      <button class="remove-btn" data-index="${i}" title="Remove">×</button>`;
    listEl.appendChild(item);
  });
  listEl.querySelectorAll(".remove-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      workspace.urls.splice(Number(btn.dataset.index), 1);
      chrome.storage.sync.set({ [storageKey]: workspace });
      renderList(listEl, workspace, storageKey);
      updateOpenAll();
    });
  });
}

function updateOpenAll() {
  const total = courseWS.urls.length + assignmentWS.urls.length;
  document.getElementById("open-all-btn").disabled = total === 0;
}

function renderMainLists() {
  renderList(document.getElementById("course-url-list"),     courseWS,     courseKey);
  renderList(document.getElementById("assignment-url-list"), assignmentWS, assignmentKey);
  updateOpenAll();
}

// ── Add handlers ───────────────────────────────────────────────────────────
function makeAddHandler(labelId, urlId, errorId, workspace, storageKey, listElId) {
  const btnId = labelId.replace("label-input", "add-btn");
  document.getElementById(urlId).addEventListener("keydown", e => {
    if (e.key === "Enter") document.getElementById(btnId).click();
  });
  document.getElementById(btnId).addEventListener("click", () => {
    const label = document.getElementById(labelId).value.trim() || "Link";
    const url   = document.getElementById(urlId).value.trim();
    const error = document.getElementById(errorId);
    if (!url.startsWith("http")) { error.textContent = "Enter a valid URL."; return; }
    error.textContent = "";
    workspace.urls.push({ label, url });
    chrome.storage.sync.set({ [storageKey]: workspace });
    renderList(document.getElementById(listElId), workspace, storageKey);
    updateOpenAll();
    document.getElementById(labelId).value = "";
    document.getElementById(urlId).value = "";
    document.getElementById(urlId).focus();
  });
}

function makeAddCurrentTabHandler(btnId, workspace, storageKey, listElId, currentTab) {
  document.getElementById(btnId).addEventListener("click", () => {
    const label = currentTab.title?.replace(/\s*\|.*$/, "").trim().slice(0, 20) || "Tab";
    workspace.urls.push({ label, url: currentTab.url });
    chrome.storage.sync.set({ [storageKey]: workspace });
    renderList(document.getElementById(listElId), workspace, storageKey);
    updateOpenAll();
  });
}

document.getElementById("open-all-btn").addEventListener("click", () => {
  [...courseWS.urls, ...assignmentWS.urls].forEach(({ url }) => chrome.tabs.create({ url }));
  window.close();
});

// ── Workspace switcher (non-Canvas tabs) ───────────────────────────────────
function showSwitcher(currentTab) {
  showView("switcher-view");

  const tabTitle = currentTab.title?.replace(/\s*\|.*$/, "").trim().slice(0, 50) || currentTab.url;
  document.getElementById("switcher-tab-title").textContent = tabTitle;

  chrome.storage.sync.get(null, (all) => {
    const switcherList = document.getElementById("switcher-list");
    const addToList    = document.getElementById("add-to-list");
    const entries = Object.entries(all).filter(([k]) => k.startsWith("course_") || k.startsWith("assignment_"));

    if (!entries.length) {
      switcherList.innerHTML = '<div class="empty-state">No workspaces yet — visit a Canvas assignment first.</div>';
      addToList.innerHTML = "";
      return;
    }

    switcherList.innerHTML = "";
    addToList.innerHTML = "";

    entries.forEach(([key, ws]) => {
      const name      = ws.name || key.replace(/_/g, " ");
      const linkCount = ws.urls?.length ?? 0;
      const type      = key.startsWith("course_") ? "Course" : "Assignment";

      // Workspace card (open all + delete)
      const card = document.createElement("div");
      card.className = "ws-card";
      card.innerHTML = `
        <div class="ws-card-header">
          <span class="ws-card-name">${name}</span>
          <span class="ws-badge">${type}</span>
        </div>
        <div class="ws-card-count">${linkCount} link${linkCount !== 1 ? "s" : ""}</div>
        <div class="ws-card-actions">
          <button class="ws-open-btn">Open All</button>
          <button class="ws-delete-btn">Delete</button>
        </div>`;
      card.querySelector(".ws-open-btn").addEventListener("click", () => {
        (ws.urls || []).forEach(({ url }) => chrome.tabs.create({ url }));
        window.close();
      });
      card.querySelector(".ws-delete-btn").addEventListener("click", () => {
        if (!confirm(`Delete "${name}"?`)) return;
        chrome.storage.sync.remove(key, () => showSwitcher(currentTab));
      });
      switcherList.appendChild(card);

      // Add-to button
      const addBtn = document.createElement("button");
      addBtn.className = "add-here-btn";
      addBtn.style.cssText = "display:block;width:100%;text-align:left;margin-bottom:6px;";
      addBtn.textContent = `+ Add to "${name}"`;
      addBtn.addEventListener("click", () => {
        const label = currentTab.title?.replace(/\s*\|.*$/, "").trim().slice(0, 20) || "Tab";
        ws.urls = ws.urls || [];
        ws.urls.push({ label, url: currentTab.url });
        chrome.storage.sync.set({ [key]: ws }, () => {
          addBtn.textContent = `✓ Added to "${name}"`;
          addBtn.disabled = true;
        });
      });
      addToList.appendChild(addBtn);
    });
  });
}

// ── Init ───────────────────────────────────────────────────────────────────
function init() {
  chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
    if (!tab?.url) return;

    const match = tab.url.match(/\/courses\/(\d+)\/assignments\/(\d+)/);
    if (!match) {
      showSwitcher(tab);
      return;
    }

    courseKey     = `course_${match[1]}`;
    assignmentKey = `assignment_${match[2]}`;

    showView("main-view");

    const titleParts     = tab.title?.split("|").map(s => s.trim()) ?? [];
    const assignmentName = titleParts[0] ?? `Assignment ${match[2]}`;
    const courseName     = titleParts.length >= 3 ? titleParts[titleParts.length - 2] : `Course ${match[1]}`;

    document.getElementById("course-label").textContent    = courseName;
    document.getElementById("assignment-name").textContent = assignmentName;

    chrome.storage.sync.get([courseKey, assignmentKey], (result) => {
      if (result[courseKey])     courseWS     = result[courseKey];
      if (result[assignmentKey]) assignmentWS = result[assignmentKey];

      courseWS.name     = courseName;
      assignmentWS.name = assignmentName;
      chrome.storage.sync.set({ [courseKey]: courseWS, [assignmentKey]: assignmentWS });

      renderMainLists();
      renderUpcoming();
      initNotes();

      makeAddHandler("course-label-input",     "course-url-input",     "course-error",     courseWS,     courseKey,     "course-url-list");
      makeAddHandler("assignment-label-input", "assignment-url-input", "assignment-error", assignmentWS, assignmentKey, "assignment-url-list");
      makeAddCurrentTabHandler("course-add-current-btn",     courseWS,     courseKey,     "course-url-list",     tab);
      makeAddCurrentTabHandler("assignment-add-current-btn", assignmentWS, assignmentKey, "assignment-url-list", tab);
    });
  });
}

// ── Notes ───────────────────────────────────────────────────────────────────
function initNotes() {
  const textarea  = document.getElementById("notes-textarea");
  const savedEl   = document.getElementById("notes-saved");

  // Load saved note
  textarea.value = assignmentWS.notes || "";

  let debounceTimer;
  textarea.addEventListener("input", () => {
    savedEl.textContent = "";
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => {
      assignmentWS.notes = textarea.value;
      chrome.storage.sync.set({ [assignmentKey]: assignmentWS }, () => {
        savedEl.textContent = "Saved";
        setTimeout(() => { savedEl.textContent = ""; }, 1500);
      });
    }, 600);
  });
}

init();
